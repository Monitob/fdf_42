/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   atohexa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/10 09:54:40 by bjacob            #+#    #+#             */
/*   Updated: 2014/02/10 10:41:44 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

int		ft_atohexa(char *s)
{
	int		i;
	char	*hex_base;
	int		result;
	int		tmp;
	int		j;

	result = 0;
	i = 0;
	hex_base = "0123456789ABCDEF";
	while (s[i] != 0)
	{
		j = (int)ft_strlen(s) - i - 1;
		tmp = 0;
		while (hex_base[tmp] != s[i])
			tmp++;
		while (j-- > 0)
			tmp *= 16;
		result += tmp;
		i++;
	}
	return (result);
}
