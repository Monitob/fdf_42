/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rtv1.h                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/01 09:20:58 by bjacob            #+#    #+#             */
/*   Updated: 2014/02/15 17:06:21 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef RTV1_H
# define RTV1_H

# include <stdlib.h>
# include <unistd.h>
# include <mlx.h>
# include <fcntl.h>
# include "libft.h"

# define DOV (1.0)
# define FOV (0.5)
# define BACKGROUND_COLOR 0xFF69B4
# define PITCH_X (e->info->width / e->info->height * 0.35)
# define PITCH_Y (e->info->height / e->info->width * PITCH_X)
# define CHECKTAB tab[1] != NULL && tab[2] != NULL && tab[3] != NULL
# define DELTA ((B * B) - (4 * A * C))
# define A ((v->x * v->x) + (v->y * v->y) + (v->z * v->z))
# define B (2 * (B_X + B_Y + B_Z))
# define B_X (v->x * (e->info->cam_x - obj->pos_x))
# define B_Y (v->y * (e->info->cam_y - obj->pos_y))
# define B_Z (v->z * (e->info->cam_z - obj->pos_z))
# define C ((C_X * C_X) + (C_Y * C_Y) + (C_Z * C_Z) + (R * R))
# define C_X (e->info->cam_x - obj->pos_x)
# define C_Y (e->info->cam_y - obj->pos_y)
# define C_Z (e->info->cam_z - obj->pos_z)
# define R (obj->radius)

typedef struct		s_point
{
	double			x;
	double			y;
	double			z;
}					t_point;

typedef struct		s_info
{
	char			*name;
	double			cam_x;
	double			cam_y;
	double			cam_z;
	int				width;
	int				height;
}					t_info;

typedef struct		s_object
{
	char			*name;
	double			radius;
	double			height;
	double			width;
	double			lenght;
	double			pos_x;
	double			pos_y;
	double			pos_z;
	int				color;
	struct s_object	*next;
}					t_object;

typedef struct		s_env
{
	void			*mlx;
	void			*win;
	t_info			*info;
	t_object		*obj;
}					t_env;

int			ft_atohexa(char *s);
void		ft_parse(char *file, t_env *e);
void		ft_init_scene(int fd, char *line, t_env *e);
t_info		*ft_init_info(t_info *info);
t_info		*ft_add_name(char **tab, t_info *info);
t_info		*ft_add_camera(char **tab, t_info *info, int fd, char *line);
t_info		*ft_add_render(char **tab, t_info *info, int fd, char *line);
t_env		*ft_add_object(char **tab, t_env *e, int fd, char *line);
t_env		*ft_push_object(t_env *e, t_object *new_obj);
t_object	*ft_init_obj(t_object *new_obj);
t_object	*ft_set_inter(char **tab, t_object *new_obj, int fd, char *line);
t_object	*ft_set_color(char **tab, t_object *new_obj, int fd, char *line);
t_object	*ft_find_inter(t_env *e, t_point *v);
int			ft_ray_trace(t_env *e, int x, int y);
int			expose_hook(t_env *e);
int			key_hook(int keycode, t_env *e);

#endif /* !RTV1_H */
