/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   set_obj.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/09 11:07:47 by bjacob            #+#    #+#             */
/*   Updated: 2014/02/15 10:44:35 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

t_env		*ft_push_object(t_env *e, t_object *new_obj)
{
	t_object	*tmp;

	tmp = e->obj;
	if (tmp == NULL)
		e->obj = new_obj;
	else
	{
		while (tmp->next != NULL)
			tmp = tmp->next;
		tmp->next = new_obj;
	}
	return (e);
}

t_object	*ft_set_color(char **tab, t_object *new_obj, int fd, char *line)
{
	while (get_next_line(fd, &line))
	{
		tab = ft_strsplit(line, ' ');
		if ((ft_strcmp(tab[0], "rgb") == 0) && CHECKTAB)
			new_obj->color = ft_atohexa(ft_strsub(tab[2], 2, 8));
		else if (ft_strcmp(tab[0], "}") == 0)
			break ;
	}
	return (new_obj);
}

t_object	*ft_set_inter(char **tab, t_object *new_obj, int fd, char *line)
{
	while (get_next_line(fd, &line))
	{
		tab = ft_strsplit(line, ' ');
		if ((ft_strcmp(tab[0], "sphere") == 0) && CHECKTAB)
			new_obj->radius = (double)ft_atoi(tab[2]);
		else if (ft_strcmp(tab[0], "pos") == 0)
		{
			if (CHECKTAB && tab[4] != NULL && tab[5] != NULL)
			{
				new_obj->pos_x = (double)ft_atoi(tab[2]);
				new_obj->pos_y = (double)ft_atoi(tab[3]);
				new_obj->pos_z = (double)ft_atoi(tab[4]);
			}
		}
		else if (ft_strcmp(tab[0], "}") == 0)
			break ;
	}
	return (new_obj);
}

t_object	*ft_init_obj(t_object *new_obj)
{
	if ((new_obj = (t_object *)malloc(sizeof(t_object))) == NULL)
	{
		write(1, "malloc fail!\n", 13);
		exit(0);
	}
	new_obj->name = NULL;
	new_obj->radius = 0.0;
	new_obj->height = 0.0;
	new_obj->width = 0.0;
	new_obj->lenght = 0.0;
	new_obj->pos_x = 0.0;
	new_obj->pos_y = 0.0;
	new_obj->pos_z = 0.0;
	new_obj->color = 0xFFFFFF;
	new_obj->next = NULL;
	return (new_obj);
}
