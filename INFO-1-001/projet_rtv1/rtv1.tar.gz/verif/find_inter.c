/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   find_inter.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/13 17:11:34 by bjacob            #+#    #+#             */
/*   Updated: 2014/02/15 17:40:16 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

t_object	*ft_find_inter(t_env *e, t_point *v)
{
	t_object	*obj;

	obj = e->obj;
	while (obj != NULL)
	{
		if (ft_strcmp(obj->name, "sphere") == 0)
		{
			if (DELTA >= 0)
				return (obj);
		}
		obj = obj->next;
	}
	return (NULL);
}
