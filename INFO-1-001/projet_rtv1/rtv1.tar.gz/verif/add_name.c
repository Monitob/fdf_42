/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   add_name.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/06 11:05:25 by bjacob            #+#    #+#             */
/*   Updated: 2014/02/07 08:36:29 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

t_info	*ft_add_name(char **tab, t_info *info)
{
	if (ft_strcmp(tab[1], "{") == 0)
	{
		if (tab[3] != NULL && ft_strcmp(tab[3], "}") == 0)
		{
			if (tab[2] != NULL)
				info->name = ft_strdup(tab[2]);
		}
	}
	return (info);
}
