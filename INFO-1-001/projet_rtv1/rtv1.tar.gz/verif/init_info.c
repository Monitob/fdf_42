/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_info.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/06 10:27:54 by bjacob            #+#    #+#             */
/*   Updated: 2014/02/07 09:04:34 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

t_info	*ft_init_info(t_info *info)
{
	if ((info = (t_info *)malloc(sizeof(t_info))) == NULL)
	{
		write(1, "malloc fail!\n", 13);
		exit(0);
	}
	info->name = "NO_NAME";
	info->cam_x = 200.0;
	info->cam_y = 0.0;
	info->cam_z = 0.0;
	info->width = 1600;
	info->height = 900;
	return (info);
}
