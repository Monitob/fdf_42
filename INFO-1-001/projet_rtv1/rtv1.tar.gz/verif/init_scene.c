/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_scene.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/06 09:01:25 by bjacob            #+#    #+#             */
/*   Updated: 2014/02/09 08:52:23 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

void	ft_init_scene(int fd, char *line, t_env *e)
{
	char	**tab;
	t_info	*info;

	info = ft_init_info(info);
	while (get_next_line(fd, &line))
	{
		tab = ft_strsplit(line, ' ');
		if (ft_strcmp(tab[0], "name") == 0)
			info = ft_add_name(tab, info);
		else if (ft_strcmp(tab[0], "camera") == 0)
			info = ft_add_camera(tab, info, fd, line);
		else if (ft_strcmp(tab[0], "render") == 0)
			info = ft_add_render(tab, info, fd, line);
		else if (ft_strcmp(tab[0], "object") == 0)
			e = ft_add_object(tab, e, fd, line);
		else if (ft_strcmp(tab[0], "}") == 0)
			break ;
	}
	if (ft_strcmp(tab[0], "}") == 0)
		e->info = info;
}
