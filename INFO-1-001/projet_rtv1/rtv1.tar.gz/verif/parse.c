/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/05 13:43:53 by bjacob            #+#    #+#             */
/*   Updated: 2014/02/07 11:05:45 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

void	ft_parse(char *file, t_env *e)
{
	int		fd;
	char	*line;

	e->info = NULL;
	e->obj = NULL;
	if ((fd = open(file, O_RDONLY)) == -1)
	{
		write(1, "open() fail!\n", 13);
		exit(0);
	}
	while (get_next_line(fd, &line))
	{
		if (ft_strcmp(line, "scene") == 0)
			ft_init_scene(fd, line, e);
	}
	close(fd);
	if (e->info == NULL)
	{
		write(1, "file empty or wrong formated.\n", 30);
		exit(0);
	}
}
