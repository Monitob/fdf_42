/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   add_camera.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/06 14:14:30 by bjacob            #+#    #+#             */
/*   Updated: 2014/02/15 09:08:55 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

t_info	*ft_add_camera(char **tab, t_info *info, int fd, char *line)
{
	while (get_next_line(fd, &line))
	{
		tab = ft_strsplit(line, ' ');
		if (ft_strcmp(tab[0], "origin") == 0)
		{
			if (tab[2] != NULL)
				info->cam_x = (double)ft_atoi(tab[2]);
			if (tab[3] != NULL)
				info->cam_y = (double)ft_atoi(tab[3]);
			if (tab[4] != NULL)
				info->cam_z = (double)ft_atoi(tab[4]);
		}
		else if (ft_strcmp(tab[0], "}") == 0)
			break ;
	}
	return (info);
}
