/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/01 09:26:36 by bjacob            #+#    #+#             */
/*   Updated: 2014/02/11 16:21:45 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

int		main(int argc, char **argv)
{
	t_env	e;

	if (argc != 2)
	{
		ft_putstr("\e[31musage: ./rtv1 [file]\e[0m\n");
		return (0);
	}
	ft_parse(argv[1], &e);
	e.mlx = mlx_init();
	e.win = mlx_new_window(e.mlx, e.info->width, e.info->height, e.info->name);
	if (e.win == NULL)
		return (0);
	mlx_key_hook(e.win, key_hook, &e);
	mlx_expose_hook(e.win, expose_hook, &e);
	mlx_loop(e.mlx);
	return (0);
}
