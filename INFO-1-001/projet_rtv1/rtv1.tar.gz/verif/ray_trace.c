/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ray_trace.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/12 09:13:54 by bjacob            #+#    #+#             */
/*   Updated: 2014/02/15 14:14:01 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

int		ft_ray_trace(t_env *e, int x, int y)
{
	t_point		v;
	t_object	*obj;

	v.x = (x - (e->info->width / 2.0)) * PITCH_X / e->info->width;
	v.y = (y - (e->info->height / 2.0)) * PITCH_Y / e->info->height;
	v.z = DOV;
	if ((obj = ft_find_inter(e, &v)) != NULL)
		return (obj->color);
	return (BACKGROUND_COLOR);
}
