/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   add_object.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/07 09:10:41 by bjacob            #+#    #+#             */
/*   Updated: 2014/02/10 10:39:56 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

t_env	*ft_add_object(char **tab, t_env *e, int fd, char *line)
{
	t_object	*new_obj;

	new_obj = ft_init_obj(new_obj);
	while (get_next_line(fd, &line))
	{
		tab = ft_strsplit(line, ' ');
		if ((ft_strcmp(tab[0], "name") == 0) && CHECKTAB)
			new_obj->name = ft_strdup(tab[2]);
		else if (ft_strcmp(tab[0], "inter") == 0)
			new_obj = ft_set_inter(tab, new_obj, fd, line);
		else if (ft_strcmp(tab[0], "color") == 0)
			new_obj = ft_set_color(tab, new_obj, fd, line);
		else if (ft_strcmp(tab[0], "}") == 0)
			break ;
	}
	e = ft_push_object(e, new_obj);
	return (e);
}
