/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   add_render.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/06 16:13:49 by bjacob            #+#    #+#             */
/*   Updated: 2014/02/07 09:03:51 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

t_info	*ft_add_render(char **tab, t_info *info, int fd, char *line)
{
	while (get_next_line(fd, &line))
	{
		tab = ft_strsplit(line, ' ');
		if (ft_strcmp(tab[0], "mlx_all_objects") == 0)
		{
			if (tab[2] != NULL)
				info->width = ft_atoi(tab[2]);
			if (tab[3] != NULL)
				info->height = ft_atoi(tab[3]);
		}
		else if (ft_strcmp(tab[0], "}") == 0)
			break ;
	}
	return (info);
}
