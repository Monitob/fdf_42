/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   expose.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/02/01 11:21:41 by bjacob            #+#    #+#             */
/*   Updated: 2014/02/16 08:39:03 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rtv1.h"

int		expose_hook(t_env *e)
{
	int		x;
	int		y;
	int		color;

	y = 0;
	while (y < e->info->height)
	{
		x = 0;
		while (x < e->info->width)
		{
			color = ft_ray_trace(e, x, y);
			mlx_pixel_put(e->mlx, e->win, x, y, color);
			x++;
		}
		y++;
	}
	return (0);
}
