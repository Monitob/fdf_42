/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   expose.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/10 14:57:28 by bjacob            #+#    #+#             */
/*   Updated: 2014/01/19 10:11:10 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"

int		expose_hook(t_env *e)
{
	int		x;
	double	ray;
	double	beta;
	double	len_ray;
	double	wall;

	x = 0;
	beta = 30.0;
	ray = e->player_angle + (FOV / 2);
	while (x < WIDTH)
	{
		if (ray < 0)
			ray += 360.0;
		len_ray = ft_ray_cast(e, ray);
		wall = (CUBE * 255.0 / len_ray) * cos(beta * PI / 180);
		ft_draw_ray((int)wall, x, e);
		ray -= FOV / WIDTH;
		beta -= FOV / WIDTH;
		x++;
	}
	return (0);
}
