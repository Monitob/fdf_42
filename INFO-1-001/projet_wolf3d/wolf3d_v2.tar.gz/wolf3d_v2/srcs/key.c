/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   key.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/10 14:45:42 by bjacob            #+#    #+#             */
/*   Updated: 2014/01/19 14:25:33 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"

int		key_press_event(int keycode, t_env *e)
{
eif (keycode == UP)
		e->move_up = 1;
	if (keycode == DOWN)
		e->move_down = 1;
	if (keycode == LEFT)
		e->move_left = 1;
	if (keycode == RIGHT)
		e->move_right = 1;
	if (keycode == ESC)
		exit(0);
	return (0);
}

int		key_release_event(int keycode, t_env *e)
{
	if (keycode == UP)
		e->move_up = 0;
	if (keycode == DOWN)
		e->move_down = 0;
	if (keycode == LEFT)
		e->move_left = 0;
	if (keycode == RIGHT)
		e->move_right = 0;
	return (0);
}

int		loop_event(t_env *e)
{
	if (e->move_up == 1)
	{
		e = ft_move_forward(e);
		expose_hook(e);
	}
	if (e->move_down == 1)
	{
		e = ft_move_backward(e);
		expose_hook(e);
	}
	if (e->move_left == 1)
	{
		e = ft_rotate_left(e);
		expose_hook(e);
	}
	if (e->move_right == 1)
	{
		e = ft_rotate_right(e);
		expose_hook(e);
	}
	return (0);
}
