/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rotate.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/18 17:41:30 by bjacob            #+#    #+#             */
/*   Updated: 2014/01/18 18:39:15 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"

t_env	*ft_rotate_left(t_env *e)
{
	e->player_angle = e->player_angle + ROTATE_ANGLE;
	if (e->player_angle > 359.5)
		e->player_angle = 0.2;
	return (e);
}

t_env	*ft_rotate_right(t_env *e)
{
	e->player_angle = e->player_angle - ROTATE_ANGLE;
	if (e->player_angle > 359.5)
		e->player_angle = 0.2;
	return (e);
}
