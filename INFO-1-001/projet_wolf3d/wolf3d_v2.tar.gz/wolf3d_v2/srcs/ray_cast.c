/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ray_cast.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/16 08:29:53 by bjacob            #+#    #+#             */
/*   Updated: 2014/01/19 11:45:41 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"

t_point	*ft_horizontal_ray(t_env *e, double ray)
{
	t_point	*a;

	a = (t_point *)malloc(sizeof(t_point));
	if (ray > 0 && ray < 180.0)
		a->y = (float)(e->player_grid_y * 64 - 1);
	else
		a->y = (float)(e->player_grid_y * 64 + 64);
	if ((a->x = HOR) > ((double)e->max_x * 64.0) || a->x < 0)
		return (NULL);
	a->x_grid = (int)(a->x / CUBE);
	a->y_grid = (int)(a->y / CUBE);
	if (e->map[a->x_grid][a->y_grid] == 1)
		return (a);
	return (ft_next_x(e, a, ray));
}

t_point	*ft_vertical_ray(t_env *e, double ray)
{
	t_point	*a;

	a = (t_point *)malloc(sizeof(t_point));
	if (ray > 270.0 || ray < 90.0)
		a->x = (float)(e->player_grid_x * 64 + 64);
	else
		a->x = (float)(e->player_grid_x * 64 - 1);
	if ((a->y = VER) > ((double)e->max_y * 64.0) || a->y < 0)
		return (NULL);
	a->x_grid = (int)(a->x / CUBE);
	a->y_grid = (int)(a->y / CUBE);
	if (e->map[a->x_grid][a->y_grid] == 1)
		return (a);
	return (ft_next_y(e, a, ray));
}

double	ft_usual_ray(t_env *e, double ray)
{
	double	hor_dist;
	double	ver_dist;
	t_point	*hor_p;
	t_point	*ver_p;

	hor_p = ft_horizontal_ray(e, ray);
	ver_p = ft_vertical_ray(e, ray);
	if (hor_p != NULL)
		hor_dist = sqrt(POW_X(hor_p->x) + POW_Y(hor_p->y));
	if (ver_p != NULL)
		ver_dist = sqrt(POW_X(ver_p->x) + POW_Y(ver_p->y));
	if (hor_p == NULL)
		return (ver_dist);
	if (ver_p == NULL)
		return (hor_dist);
	if (hor_dist < ver_dist)
		return (hor_dist);
	return (ver_dist);
}

double	ft_ray_cast(t_env *e, double ray)
{
	double	hor_dist;
	double	ver_dist;
	t_point	*hor_p;
	t_point	*ver_p;

	if (ray == 0 || ray == 180.0)
	{
		hor_dist = -1.0;
		ver_p = ft_vertical_ray(e, ray);
		ver_dist = sqrt(POW_X(ver_p->x)) + POW_Y(ver_p->y);
		return (ver_dist);
	}
	else if (ray == 90.0 || ray == 270.0)
	{
		ver_dist = -1.0;
		hor_p = ft_horizontal_ray(e, ray);
		hor_dist = sqrt(POW_X(hor_p->x)) + POW_Y(hor_p->y);
		return (hor_dist);
	}
	else
		return (ft_usual_ray(e, ray));
}
