/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   draw_ray.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/17 09:21:08 by bjacob            #+#    #+#             */
/*   Updated: 2014/01/19 14:20:34 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"

char	*ft_draw_sky(char *image, int len)
{
	int		i;

	i = 0
	while (i < len)
	{
		image[i] = 254;
		image[i + 1] = 234;
		image[i + 2] = 169;
		image[i + 3] = 0;
		i = i + 4;
	}
	return (image);
}

char	*ft_draw_ground(char *image, int i)
{
	while (i < (HEIGHT * 4))
	{
		image[i] = 12;
		image[i + 1] = 0;
		image[i + 2] = 62;
		image[i + 3] = 0;
		i = i + 4;
	}
	return (image);
}

char	*ft_draw_wall(char *image, int i, int wall)
{
	while (wall > 0)
	{
		image[i] = 128;
		image[i + 1] = 128;
		image[i + 2] = 128;
		image[i + 3] = 0;
		i = i + 4;
		wall--;
	}
	return (image);
}

void	ft_draw_ray(int wall, int x, t_env *e)
{
	void	*new_image;
	char	*image;
	int		bpp;
	int		size_line;

	new_image = mlx_new_image(e->mlx, 1, HEIGHT);
	image = mlx_get_data_addr(new_image, &bpp, &size_line, &e->endian);
	image = ft_draw_sky(image, ((HEIGHT - wall) / 2) * 4);
	image = ft_draw_wall(image, ((HEIGHT - wall) / 2) * 4, wall);
	image = ft_draw_ground(image, (((HEIGHT - wall) / 2) * 4) + (wall * 4));
	mlx_put_image_to_window(e->mlx, e->win, new_image, x, 0);
	mlx_destroy_image(e->mlx, new_image);
}
