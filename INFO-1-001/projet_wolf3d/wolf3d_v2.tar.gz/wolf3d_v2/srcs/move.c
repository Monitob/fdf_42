/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   move.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/18 13:59:51 by bjacob            #+#    #+#             */
/*   Updated: 2014/01/18 18:55:03 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"

t_env	*ft_move_forward(t_env *e)
{
	double		x_move;
	double		y_move;
	int			tmp_x;
	int			tmp_y;

	x_move = (e->player_x + (cos(e->player_angle) * MOVE_DIST));
	y_move = (e->player_y + (sin(e->player_angle) * MOVE_DIST));
	tmp_x = (int)(x_move / CUBE);
	tmp_y = (int)(y_move / CUBE);
	if (e->map[tmp_x][tmp_y] != 1)
	{
		e->player_x = x_move;
		e->player_y = y_move;
		e->player_grid_x = tmp_x;
		e->player_grid_y = tmp_y;
	}
	return (e);
}

t_env	*ft_move_backward(t_env *e)
{
	double		x_move;
	double		y_move;
	int			tmp_x;
	int			tmp_y;

	x_move = (e->player_x - (cos(e->player_angle) * MOVE_DIST));
	y_move = (e->player_y - (sin(e->player_angle) * MOVE_DIST));
	tmp_x = (int)(x_move / CUBE);
	tmp_y = (int)(y_move / CUBE);
	if (e->map[tmp_x][tmp_y] != 1)
	{
		e->player_x = x_move;
		e->player_y = y_move;
		e->player_grid_x = tmp_x;
		e->player_grid_y = tmp_y;
	}
	return (e);
}
