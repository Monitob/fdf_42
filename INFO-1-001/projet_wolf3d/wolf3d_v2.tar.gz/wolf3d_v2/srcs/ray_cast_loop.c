/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ray_cast_loop.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/17 07:46:56 by bjacob            #+#    #+#             */
/*   Updated: 2014/01/17 18:02:33 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"

t_point		*ft_next_x(t_env *e, t_point *a, double ray)
{
	t_point	next;

	if (ray < 180.0)
		next.y = -64.0;
	else
		next.y = 64.0;
	next.x = 64.0 / tan(ray * PI / 180);
	while (1)
	{
		a->x = a->x + next.x;
		a->y = a->y + next.y;
		a->x_grid = (int)(a->x / 64.0);
		a->y_grid = (int)(a->y / 64.0);
		if (a->x_grid < 0 || a->x_grid > (e->max_x - 1))
			return (NULL);
		if (a->y_grid < 0 || a->y_grid > (e->max_y - 1))
			return (NULL);
		if (e->map[a->x_grid][a->y_grid] == 1)
			return (a);
	}
}

t_point		*ft_next_y(t_env *e, t_point *a, double ray)
{
	t_point	next;

	if (ray > 270.0 || ray < 90.0)
		next.x = 64.0;
	else
		next.x = -64.0;
	next.y = 64.0 * tan(ray * PI / 180);
	while (1)
	{
		a->x = a->x + next.x;
		a->y = a->y + next.y;
		a->x_grid = (int)(a->x / 64.0);
		a->y_grid = (int)(a->y / 64.0);
		if (a->x_grid < 0 || a->x_grid > (e->max_x - 1))
			return (NULL);
		if (a->y_grid < 0 || a->y_grid > (e->max_y - 1))
			return (NULL);
		if (e->map[a->x_grid][a->y_grid] == 1)
			return (a);
	}
}
