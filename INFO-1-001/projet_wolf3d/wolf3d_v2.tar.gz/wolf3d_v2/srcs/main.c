/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/10 13:56:08 by bjacob            #+#    #+#             */
/*   Updated: 2014/01/19 14:25:47 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"

int		main(int argc, char **argv)
{
	t_env		e;
	int			**map;

	map = ft_init_map(argc, argv, &e);
	e.map = map;
	e.player_x = ((PLAYER_START_X + 1) * 64) - 32;
	e.player_y = ((PLAYER_START_Y + 1) * 64) - 32;
	e.player_grid_x = PLAYER_START_X;
	e.player_grid_y = PLAYER_START_Y;
	e.player_angle = PLAYER_ANGLE;
	e.mlx = mlx_init();
	if ((e.win = mlx_new_window(e.mlx, WIDTH, HEIGHT, "Wolf3D")) == NULL)
		return (0);
	mlx_expose_hook(e.win, expose_hook, &e);
	mlx_do_key_autorepeatoff(e.mlx);
	mlx_hook(e.win, KeyPress, KeyPressMask, &key_press_event, &e);
	mlx_hook(e.win, KeyRelease, KeyReleaseMask, &key_release_event, &e);
	mlx_loop_hook(e.mlx, &loop_event, &e);
	mlx_loop(e.mlx);
	return (0);
}
