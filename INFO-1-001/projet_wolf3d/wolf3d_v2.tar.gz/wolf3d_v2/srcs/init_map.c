/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_map.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/11 08:27:37 by bjacob            #+#    #+#             */
/*   Updated: 2014/01/19 07:53:44 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "wolf3d.h"

int		*ft_read_line(t_file *file)
{
	int		*map;
	int		i;
	char	**tab;

	i = 0;
	map = (int *)malloc(sizeof(int) * ((ft_strlen(file->str) + 1) / 2));
	tab = ft_strsplit(file->str, ' ');
	while (tab[i] != NULL)
	{
		map[i] = ft_atoi(tab[i]);
		i++;
	}
	return (map);
}

int		ft_lenlist(t_file *file)
{
	int	i;

	i = 0;
	while (file != NULL)
	{
		file = file->next;
		i++;
	}
	return (i);
}

void	ft_new_elem(t_file *file, char *str)
{
	t_file	*new_elem;

	if ((new_elem = (t_file *)malloc(sizeof(t_file))) == NULL)
		exit(0);
	new_elem->str = str;
	new_elem->next = NULL;
	while (file->next != NULL)
		file = file->next;
	file->next = new_elem;
}

t_file	*ft_read_file(char **argv)
{
	char	*line;
	t_file	*file;
	int		fd;

	if (ft_strncmp(argv[1], "map/level", 9) != 0)
	{
		write(1, "Wolf3D usage: ./wolf3d map/levelX\n", 34);
		exit(0);
	}
	if ((fd = open(argv[1], O_RDONLY)) == -1)
	{
		write(1, "open() fail!\n", 13);
		exit(0);
	}
	if (get_next_line(fd, &line))
	{
		if ((file = (t_file *)malloc(sizeof(t_file))) == NULL)
			exit(0);
		file->str = line;
		file->next = NULL;
	}
	while (get_next_line(fd, &line))
		ft_new_elem(file, line);
	return (file);
}

int		**ft_init_map(int argc, char **argv, t_env *e)
{
	int		**map;
	t_file	*file;
	int		i;

	i = 0;
	if (argc != 2)
	{
		write(1, "Wolf3D usage: ./wolf3d map/levelX\n", 34);
		exit(0);
	}
	file = ft_read_file(argv);
	e->max_y = ft_lenlist(file);
	e->max_x = (ft_strlen(file->str) + 1) / 2;
	map = (int **)malloc(sizeof(int *) * ft_lenlist(file));
	while (file != NULL)
	{
		map[i] = ft_read_line(file);
		file = file->next;
		i++;
	}
	return (map);
}
