/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   wolf3d.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: bjacob <bjacob@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/01/10 14:22:04 by bjacob            #+#    #+#             */
/*   Updated: 2014/01/19 14:07:00 by bjacob           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef WOLF3D_H
# define WOLF3D_H

# include <mlx.h>
# include <math.h>
# include <fcntl.h>
# include <unistd.h>
# include <stdlib.h>
# include </opt/X11/include/X11/X.h>
# include "libft.h"

# define PI (3.14159265358)
# define POW_X(i) pow((e->player_x - i), 2)
# define POW_Y(j) pow((e->player_y - j), 2)
# define HOR (e->player_x + (e->player_y - a->y) / tan(ray * PI / 180))
# define VER (e->player_y + (e->player_x - a->x) * tan(ray * PI / 180))

# define WIDTH (1280.0)
# define HEIGHT (800.0)
# define CUBE (64.0)

# define PLAYER_START_X (2)
# define PLAYER_START_Y (2)
# define PLAYER_ANGLE (90.0)
# define FOV (60.0)
# define HOV (32.0)
# define ROTATE_ANGLE (1.5)
# define MOVE_DIST (2)

# define ESC 65307
# define UP 65362
# define DOWN 65364
# define LEFT 65361
# define RIGHT 65363

typedef struct		s_file
{
	char			*str;
	struct s_file	*next;
}					t_file;

typedef struct		s_point
{
	double			x;
	int				x_grid;
	double			y;
	int				y_grid;
}					t_point;

typedef struct		s_env
{
	void			*mlx;
	void			*win;
	int				**map;
	int				max_x;
	int				max_y;
	double			player_x;
	int				player_grid_x;
	double			player_y;
	int				player_grid_y;
	double			player_angle;
	int				move_up;
	int				move_down;
	int				move_left;
	int				move_right;
	int				endian;
}					t_env;

int			expose_hook(t_env *e);
double		ft_ray_cast(t_env *e, double ray);
t_point		*ft_next_x(t_env *e, t_point *a, double ray);
t_point		*ft_next_y(t_env *e, t_point *a, double ray);
void		ft_draw_ray(int wall, int x, t_env *e);
t_env		*ft_move_forward(t_env *e);
t_env		*ft_move_backward(t_env *e);
t_env		*ft_rotate_left(t_env *e);
t_env		*ft_rotate_right(t_env *e);
int			key_press_event(int keycode, t_env *e);
int			key_release_event(int keycode, t_env *e);
int			loop_event(t_env *e);
int			**ft_init_map(int argc, char **argv, t_env *e);

#endif /* !WOLF3D_H */
