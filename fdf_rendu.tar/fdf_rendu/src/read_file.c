/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   read_file.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jbernabe <jbernabe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2014/04/21 18:50:11 by jbernabe          #+#    #+#             */
/*   Updated: 2014/04/22 16:33:40 by jbernabe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h> //
#include "fdf.h"

void	read_to_transform(t_fdf *ptr, char **map)
{
	int			i;
	char		**tab_char;
	int			len_tab;
	t_grille	*list_tab_int;

	len_tab = ft_tab_len(map);
	if (!(list_tab_int = (t_grille *)malloc(sizeof(t_grille))))
		return ;
	if (!(tab_char = (char **)malloc(sizeof(char *) * len_tab + 1)))
	 	return ;
	tab_char[len_tab + 1] = NULL;
/*recibimos un doble tab sin espacions, esto lo pasamos a un tab de dos dimensiones
que contiene a la vez un tab de dos dimensiones
de esta manerana

tab_loca[tab[sin espacio1], tab[sin espacion 2]]
0tab[0][0] = 10
1tab[0][1] = 10
2tab[1][0] = 10
3tab[1][1] = 10

----------------
    0         
   2  1     
     3       
             
----------------
*/
	i = 0;
	while (map[i] != NULL)
	{
		tab_char[i] = map[i];
		i++;
	}
	tab_to_int(tab_char, &list_tab_int), ptr);
}	

void	read_file(int fd, t_fdf *ptr)
{
	int		ret;
	char	*map;

	while ((ret = get_next_line(fd, &map)))
	{
		printf("map-> %s\n", map);
		read_to_transform(ptr, (ft_strsplit(map, ' ')));
		free(map);
		if (ret == 0)
			break ;
	}
	(void)ptr;
}